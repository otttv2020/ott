import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,datetime,os,json,base64,plugintools,xbmc
from datetime import datetime as dtdeep
import xml.etree.ElementTree as ElementTree
import time, urllib2

reload(sys)
sys.setdefaultencoding('utf8')
global confirm

AddonID = 'plugin.video.ottalpha'
dialog       =  xbmcgui.Dialog()
addonDir = plugintools.get_runtime_path()
icon = addonDir+"/fanart.jpg"
main_url= "http://mlsh1.com"
port_num="2086"
user_name= plugintools.get_setting("deviceUser")
pass_word= plugintools.get_setting("devicePass")
tv_link = "%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories" %(main_url,port_num,user_name,pass_word)
movies_url   = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories'%(main_url,port_num,user_name,pass_word)
series_url   ='%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories'%(main_url,port_num,user_name,pass_word)
PlayerAPI = "%s:%s/player_api.php?username=%s&password=%s" %(main_url,port_num,user_name,pass_word)
art_path = os.path.join( plugintools.get_runtime_path() , "resources" , "art" )

def run():
    global tv_link
    global LiveCats
    global PlayerAPI
    global main_url
    global art_path
    global user_name
    global pass_word       
    
    params = plugintools.get_params()
    if params.get("action") is None:
        main_menu(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    plugintools.close_item_list()

def main_menu(params):

    if not main_url:
        plugintools.open_settings_dialog()

    channels = confirm()
    if channels == 1:
    
        plugintools.set_view( plugintools.LIST )
         
        plugintools.add_item( action=sync_data("execute_ainfo"),   title="Account Information", thumbnail=os.path.join(art_path,"myacco.png"), fanart="" ,  folder=True )
        
        plugintools.add_item( action=sync_data("security_check"),  title="Live TV" , thumbnail=os.path.join(art_path,"otttv1.png") , fanart="" ,  folder=True )

        plugintools.add_item( action=sync_data("movies"),   title="Movies" , url= 'movies', thumbnail=os.path.join(art_path,"movies.png"), fanart="" , folder=True )
        
        plugintools.add_item( action=sync_data("series"),   title="TV Series" , url= 'series', thumbnail=os.path.join(art_path,"tvseries.png"), fanart="" , folder=True )

        plugintools.add_item( action=sync_data("speedtest"),   title="Speed Test" , thumbnail=os.path.join(art_path,"speed.png"), fanart="" , folder=False )
        
    elif channels != 1:
    
        plugintools.add_item( action=sync_data("license_check"), title="Step 1: Click here to insert login details" , thumbnail=os.path.join(art_path,"myacco.png"), fanart="", folder=False )
        	
        plugintools.add_item( action=sync_data("license_check2"), title="Step 2: Click here to confirm details" , thumbnail=os.path.join(art_path,"myacco.png"), fanart="", folder=False )

def movies(params):
	if params.get("url") =="movies":
		open = open_url(movies_url)
	else:
		open = open_url(params.get("url"))
	all_cats = plugintools.regex_get_all(open,'<channel>','</channel>')
	for a in all_cats:
		if '<playlist_url>' in open:
			name = plugintools.regex_from_to(a,'<title>','</title>')
			url1  = plugintools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
			plugintools.add_item( action=sync_data("movies"),   title=str(base64.b64decode(name)).replace('?','') , url=url1, thumbnail=os.path.join(art_path,"movies.png"), fanart=icon, folder=True )
		else:
			name = plugintools.regex_from_to(a,'<title>','</title>')
			name = base64.b64decode(name)
			prog_img= plugintools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
			item_url  = plugintools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
			show_desc = plugintools.regex_from_to(a,'<description>','</description>')
			plugintools.add_item( action=sync_data("run_cronjob"), title=name , url=item_url, thumbnail=prog_img, plot=base64.b64decode(show_desc), fanart=icon, extra="", isPlayable=True, folder=False )
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)

def series(params):
	if params.get("url") =="series":
		open = open_url(series_url)
	else:
		open = open_url(params.get("url"))
	all_cats = plugintools.regex_get_all(open,'<channel>','</channel>')
	for a in all_cats:
		if '<playlist_url>' in open:
			name = plugintools.regex_from_to(a,'<title>','</title>')
			url1  = plugintools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
			plugintools.add_item( action=sync_data("series"),   title=str(base64.b64decode(name)).replace('?','') , url=url1, thumbnail=os.path.join(art_path,"series.png"), fanart=icon, folder=True )
		else:
			name = plugintools.regex_from_to(a,'<title>','</title>')
			name = base64.b64decode(name)
			prog_img= plugintools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
			item_url  = plugintools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
			show_desc = plugintools.regex_from_to(a,'<description>','</description>')
			plugintools.add_item( action=sync_data("run_cronjob"), title=name , url=item_url, thumbnail=prog_img, plot=base64.b64decode(show_desc), fanart=icon, extra="", isPlayable=True, folder=False )
				
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)


def license_check(params):
    plugintools.open_settings_dialog()

                
def license_check2(params):
	if not user_name:
		xbmc.executebuiltin('Notification(No Username!,[COLOR white]Username cannot be blank![/COLOR],3000,%s)'%(icon))
		plugintools.open_settings_dialog()
	if not pass_word:
		xbmc.executebuiltin('Notification(No Password!,[COLOR white]Password cannot be blank![/COLOR],3000,%s)'%(icon))
		plugintools.open_settings_dialog()
	d = urllib.urlopen(PlayerAPI)
	FileInfo = d.info()['Content-Type']
	if not 'application/json' in FileInfo:
		dialog.ok('[COLOR white]Invalid or Expired Account[/COLOR]','[COLOR white]Invalid or Expired Account found[/COLOR]','[COLOR white]Please check your spelling and case sensitivity[/COLOR]','[COLOR white]Check your password with the team otherwise[/COLOR]')
		plugintools.open_settings_dialog()
	else:
		xbmc.executebuiltin('Container.Refresh')


def security_check(params):
    request = urllib2.Request(tv_link, headers={"Accept" : "application/xml"})
    u = urllib2.urlopen(request)
    tree = ElementTree.parse(u)
    rootElem = tree.getroot()
    for channel in tree.findall(sync_data("channel")):
        tvTitle = channel.find("title").text
        tvTitle = (tvTitle)
        tvTitle = base64.b64decode(tvTitle)
        cat_link = channel.find("playlist_url").text
        plugintools.add_item( action=sync_data("LiveCategory"), title=tvTitle , url=cat_link, thumbnail=params.get("thumbnail"), fanart="", folder=True)
                 

def open_url(url):
    try:
        req = urllib2.Request(url)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
    except:pass


def LiveCategory(params):
	ALL_LIVE = params.get("url")
	request = urllib2.Request(ALL_LIVE, headers={"Accept" : "application/xml"})
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
		
	for channel in tree.findall(sync_data("channel")):
		tvTitle = channel.find("title").text
		tvTitle = (tvTitle)
		tvTitle = base64.b64decode(tvTitle)
		tvTitle = tvTitle.partition("[")
		stream_link = channel.find("stream_url").text 
		item_url = stream_link
		if "http://mlsh1.com/enigma2.php"  in stream_link: 
			item_url = stream_link.split(user_name,1)[1]
			item_url = item_url.split(pass_word,1)[1]
			item_url = item_url.split("/",1)[1]			
		prog_img = channel.find(sync_data("desc_image")).text
		display_title = tvTitle[1]+tvTitle[2]
		display_title = display_title.partition("]")
		display_title = display_title[2]
		display_title = display_title.partition("   ")
		display_title = display_title[2]
		show_item = "[B][COLOR ffffffff]%s[/COLOR][/B] [COLOR FF12A0C7]- [/COLOR]" % (tvTitle[0]).upper()+display_title
		#show_item = show_item.upper()		
		item_desc = channel.find(sync_data("description")).text
			
		if item_desc:
			try:
				item_desc = (item_desc)
				now_desc = item_desc.partition("(")
				now_desc = base64.b64decode(now_desc[0])
				now_desc = re.sub(r"\[/?.*?\]",'',str(now_desc))
				now_desc = re.sub(r"\[/?.*?",'',now_desc)
				on_now = "[COLOR ffffffff][B]Now[/COLOR][COLOR FF12A0C7] :[/B][/COLOR][B][COLOR ffffffff]" +str(now_desc).split('(')[0]+"[/COLOR][/B]"+ str(now_desc).split('\n')[1].split(')\n')[0]
				next_desc = item_desc.partition(")\n")
				next_desc = next_desc[2].partition("(")
				next_desc = re.sub(r"\[/?.*?\]",'',str(next_desc))
				next_desc = re.sub(r"\[/?.*?",'',next_desc)
			
				next_desc = "[COLOR ffffffff][B]\n\nNext[/COLOR][COLOR FFFFFF00] :[/B][/COLOR][B][COLOR ffffffff]" +str(now_desc).split(')\n')[1].split('\n')[0]+"[/COLOR][/B]\n"+ str(now_desc).split(')\n')[1].split('\n')[1]
				show_desc = on_now.replace('( ','').replace(')','')+next_desc.replace('( ','').replace(')','')
			except:
				show_desc = ""
			
		else:
			show_desc = ""
						
		if prog_img:
			plugintools.add_item( action=sync_data("run_cronjob"), title=show_item , url=item_url, thumbnail=prog_img, plot=show_desc, fanart=os.path.join(art_path,sync_data("theater.jpg")), extra="", isPlayable=True, folder=False )
			
		else:
			plugintools.add_item( action=sync_data("run_cronjob"), title=show_item , url=item_url, thumbnail=os.path.join(art_path,"allchannels.png") , plot=show_desc, fanart='' , extra="", isPlayable=True, folder=False )
	plugintools.set_view( plugintools.EPISODES )


def run_cronjob(params):
    cronjob_url = params.get("url")
    cronjob_url = str(cronjob_url).replace('USERNAME',user_name).replace('PASSWORD',pass_word)
    if "http://"  not in cronjob_url: 
        cronjob_url = "http://%s:%s/enigma.php/live/%s/%s/%s" %(main_url,port_num,user_name,pass_word,cronjob_url)
        cronjob_url = cronjob_url[:-2]
        cronjob_url = cronjob_url + "ts"
    listitem = xbmcgui.ListItem(path=cronjob_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def sync_data(sync):
    data = (sync)
    return data


def confirm():
	if not user_name:
		return 0
	else:
		d = urllib.urlopen(PlayerAPI)
		FileInfo = d.info()['Content-Type']
		if not FileInfo =='application/json':
			dialog.ok('[COLOR white]Invalid or Expired Account[/COLOR]','[COLOR white]Invalid or Expired Account found[/COLOR]','[COLOR white]Please check your spelling and case sensitivity[/COLOR]','[COLOR white]Check your password with the team otherwise[/COLOR]')
		else:
			return 1

    
def execute_ainfo(params):
	data = json.load(urllib2.urlopen(PlayerAPI))
	today = datetime.date.today()
	x=data['user_info']
	Username = x['username']
	Status = x['status']
	Creation = x['created_at']
	Created = datetime.datetime.fromtimestamp(int(Creation)).strftime('%H:%M %d/%m/%Y')
	Current = x['active_cons']
	Max = x['max_connections']
	Expiry = x['exp_date']
	if Expiry == None:
		Expired = 'Never'
	else:
		Expired = datetime.datetime.fromtimestamp(int(Expiry)).strftime('%H:%M %d/%m/%Y')

	plugintools.add_item( action="",   title="[COLOR white]User: [/COLOR]"+Username, thumbnail=os.path.join(art_path,"myacco.png") , fanart="" , folder=False )
	plugintools.add_item( action="",   title="[COLOR white]Status: [/COLOR]"+Status, thumbnail=os.path.join(art_path,"myacco.png") , fanart="" , folder=False )
	plugintools.add_item( action="",   title="[COLOR white]Created: [/COLOR]"+Created, thumbnail=os.path.join(art_path,"myacco.png") , fanart="" , folder=False )
	plugintools.add_item( action="",   title="[COLOR white]Expires: [/COLOR]"+Expired, thumbnail=os.path.join(art_path,"myacco.png") , fanart="" , folder=False )
	plugintools.add_item( action="",   title="[COLOR white]Max connections: [/COLOR]"+Max, thumbnail=os.path.join(art_path,"myacco.png") , fanart="" , folder=False )
	plugintools.add_item( action="",   title="[COLOR white]Active connections: [/COLOR]"+Current, thumbnail=os.path.join(art_path,"myacco.png") , fanart="", folder=False )

	plugintools.set_view( plugintools.LIST )


def speedtest(params):
    xbmc.executebuiltin('Runscript("special://home/addons/'+AddonID+'/speedtest.py")')
run()